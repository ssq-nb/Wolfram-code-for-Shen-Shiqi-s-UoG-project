(* ::Title:: *)
(* Figure 3.2: binary entropy for three population fractions *)

(* This file is self-contained. Evaluating it exports
   figure3_2_entropy_gamma.pdf to the sibling directory "figures 3". *)

ClearAll["Global`*"];

notebookDirectory = Quiet@Check[NotebookDirectory[], $Failed];
sourceDirectory = Which[
  StringQ[$InputFileName] && StringLength[$InputFileName] > 0,
  DirectoryName[$InputFileName],
  StringQ[notebookDirectory], notebookDirectory,
  True, Directory[]];
sourceDirectory = ExpandFileName[sourceDirectory];
projectDirectory = If[FileNameTake[sourceDirectory] === "wolfram",
  DirectoryName[sourceDirectory], sourceDirectory];
figureDirectory = FileNameJoin[{projectDirectory, "figures 3"}];
If[! DirectoryQ[figureDirectory],
 CreateDirectory[figureDirectory, CreateIntermediateDirectories -> True]];

binaryEntropy[m_] := Piecewise[{{0, Abs[m] == 1}},
  -((1 + m)/2) Log[(1 + m)/2]
   - ((1 - m)/2) Log[(1 - m)/2]];

entropy[ma_, mb_, gamma_] :=
 gamma binaryEntropy[ma] + (1 - gamma) binaryEntropy[mb];

entropyPanel[gamma_] := DensityPlot[
  Evaluate[entropy[ma, mb, gamma]], {ma, -1, 1}, {mb, -1, 1},
  PlotRange -> {0, Log[2]}, PlotPoints -> 100, MaxRecursion -> 1,
  ColorFunction -> "SolarColors", ColorFunctionScaling -> True,
  PlotLegends -> BarLegend[{"SolarColors", {0, Log[2]}},
    LegendMarkerSize -> 185,
    LabelStyle -> {FontFamily -> "Times", 10.5}],
  Frame -> True, Axes -> False, AspectRatio -> 1,
  FrameStyle -> Directive[GrayLevel[0.25], AbsoluteThickness[0.9]],
  FrameTicksStyle -> Directive[GrayLevel[0.25], 10.5],
  FrameLabel -> {Style[Subscript[M, A], 14], Style[Subscript[M, B], 14]},
  PlotLabel -> Style[Row[{\[Gamma], " = ", NumberForm[gamma, {2, 1}]}],
    14, FontFamily -> "Times"],
  BaseStyle -> {FontFamily -> "Times", 11}, ImagePadding -> 42];

figure32 = GraphicsRow[entropyPanel /@ {1/10, 1/2, 9/10},
  Spacings -> 14, ImageSize -> 1200, Background -> White];

exportPath = FileNameJoin[{figureDirectory,
   "figure3_2_entropy_gamma.pdf"}];
Export[exportPath, figure32, "PDF"];
Print["PDF exported to: ", exportPath];
