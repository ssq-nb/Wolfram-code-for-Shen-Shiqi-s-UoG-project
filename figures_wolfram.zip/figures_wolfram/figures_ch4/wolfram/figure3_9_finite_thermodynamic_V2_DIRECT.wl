(* ::Package:: *)

(* ::Title:: *)
(* Figure 3.9 V2 DIRECT: finite-N rounding and thermodynamic selection *)



ClearAll["Global`*"];

codeVersion = "2026-09-03-V2-DIRECT";
Print["RUNNING CODE VERSION: ", codeVersion];

notebookDirectory = Quiet@Check[NotebookDirectory[], $Failed];
sourceDirectory = Which[
  StringQ[$InputFileName] && StringLength[$InputFileName] > 0,
  DirectoryName[$InputFileName],
  StringQ[notebookDirectory], notebookDirectory,
  True, Directory[]];
sourceDirectory = ExpandFileName[sourceDirectory];
projectDirectory = If[FileNameTake[sourceDirectory] === "wolfram",
  DirectoryName[sourceDirectory], sourceDirectory];
figureDirectory = FileNameJoin[{projectDirectory, "figures 3"}];
If[! DirectoryQ[figureDirectory],
 CreateDirectory[figureDirectory, CreateIntermediateDirectories -> True]];

(* Chapter 3 reference section:
   gamma=1/2, rho=1, delta=1, eta=0, x=y=h. *)
tPlot = 3/2;
nTotals = {20, 50, 100};

pairwisePart[mA_, mB_] :=
  (mA^2 + mA mB + mB^2)/8;

mixedCubicPart[mA_, mB_] :=
  (mA^2 mB + mA mB^2)/16;

interactionPolynomial[mA_, mB_] :=
  pairwisePart[mA, mB] + mixedCubicPart[mA, mB];

equationOfState[m_] :=
  ArcTanh[m] - 3 tPlot m (2 + m)/8;

(* Independently validated solution of the stationary and equal-height
   equations at t=3/2. Exact decimal rationals are used here. *)
mMinus = -42846901613714256/10^17;
mZero = 30179645919104126/10^17;
mPlus = 8659919628855233/10^16;
hCoexistence = -7925922930167452/10^17;

Print["Fixed validated values:"];
Print["{mMinus,mZero,mPlus,hCoexistence} = ",
 N[{mMinus, mZero, mPlus, hCoexistence}, 12]];

(* Each row is {M_A,M_B,log multiplicity + interaction exponent}. *)
finiteGrid[nTotal_Integer] := Module[
  {nA, nB},
  If[OddQ[nTotal],
   Print["ERROR: N must be even for gamma=1/2."];
   Abort[]
  ];
  nA = Quotient[nTotal, 2];
  nB = Quotient[nTotal, 2];
  N[
   Flatten[
    Table[
     Module[{mAValue, mBValue},
      mAValue = (2 k - nA)/nA;
      mBValue = (2 ell - nB)/nB;
      {
       mAValue,
       mBValue,
       Log[Binomial[nA, k]] + Log[Binomial[nB, ell]]
        + nTotal tPlot pairwisePart[mAValue, mBValue]
        + nTotal tPlot mixedCubicPart[mAValue, mBValue]
      }
     ],
     {k, 0, nA}, {ell, 0, nB}
    ],
    1
   ],
   MachinePrecision
  ]
];

finiteMean[nTotal_Integer, grid_, hValue_?NumericQ] := Module[
  {logWeights, shift, weights, meanA, meanB},
  logWeights = grid[[All, 3]]
    + nTotal hValue (grid[[All, 1]] + grid[[All, 2]])/2;
  shift = Max[logWeights];
  weights = Exp[logWeights - shift];
  meanA = Total[grid[[All, 1]] weights]/Total[weights];
  meanB = Total[grid[[All, 2]] weights]/Total[weights];
  If[Abs[meanA - meanB] > 10^-10,
   Print["ERROR: exchange symmetry failed at h=", hValue, "."];
   Abort[]
  ];
  meanA
];

(* Precompute each double-binomial grid once. *)
grids = Association@Table[nValue -> finiteGrid[nValue],
   {nValue, nTotals}];

(* Diagnostic that distinguishes this model from the pairwise-only model.
   Pairwise-only curves give m_N(0)=0. The cubic model must give the three
   positive values below. *)
zeroFieldExpectations = Table[
  finiteMean[nValue, grids[nValue], 0.0],
  {nValue, nTotals}
];
expectedZeroField = {0.6441329182, 0.8521362369, 0.8862692019};

Print["finite-N check at h=0: ", zeroFieldExpectations];

If[Max[Abs[zeroFieldExpectations - expectedZeroField]] > 10^-6,
 Print["ERROR: finite-N weights do not contain the intended cubic term."];
 Print["Expected: ", expectedZeroField];
 Abort[]
];

fieldMinimum = -23/100;
fieldMaximum = 8/100;
finiteFields = N[Subdivide[fieldMinimum, fieldMaximum, 260]];

finiteData = Table[
  ({#, finiteMean[nValue, grids[nValue], #]} &) /@ finiteFields,
  {nValue, nTotals}
];

finiteColours = {
  RGBColor[0.38, 0.64, 0.82],
  RGBColor[0.11, 0.39, 0.68],
  RGBColor[0.05, 0.19, 0.36]
};
thermodynamicColour = RGBColor[0.78, 0.18, 0.16];
coexistenceColour = RGBColor[0.05, 0.52, 0.42];
gridColour = GrayLevel[0.90];

finitePlot = ListLinePlot[
  finiteData,
  PlotStyle -> (Directive[#, AbsoluteThickness[2.25]] & /@ finiteColours),
  InterpolationOrder -> 2
];

(* Direct parametric representation of the two globally selected branches.
   At coexistence the thermodynamic solution jumps from mMinus to mPlus. *)
thermodynamicLow = ParametricPlot[
  Evaluate[{equationOfState[m], m}],
  {m, -9999/10000, mMinus},
  PlotStyle -> Directive[thermodynamicColour, Dashed,
    AbsoluteThickness[2.5]],
  PlotPoints -> 450,
  MaxRecursion -> 3
];

thermodynamicHigh = ParametricPlot[
  Evaluate[{equationOfState[m], m}],
  {m, mPlus, 9999/10000},
  PlotStyle -> Directive[thermodynamicColour, Dashed,
    AbsoluteThickness[2.5]],
  PlotPoints -> 450,
  MaxRecursion -> 3
];

markerGraphics = Graphics[{
   Directive[coexistenceColour, Dashed, AbsoluteThickness[1.7]],
   Line[N[{{hCoexistence, -1}, {hCoexistence, 1}}]],
   coexistenceColour, PointSize[0.015],
   Point[N[{{hCoexistence, mMinus}, {hCoexistence, mPlus}}]],
   Inset[
    Style[
     Row[{Subscript[h, "coex"], " = ",
       NumberForm[N[hCoexistence], {6, 4}]}],
     11, Bold, FontFamily -> "Times", Background -> White
    ],
    N[{hCoexistence + 0.035, -0.82}]
   ]
}];

figure39Raw = Show[
  finitePlot,
  thermodynamicLow,
  thermodynamicHigh,
  markerGraphics,
  Frame -> True,
  Axes -> False,
  Background -> White,
  FrameStyle -> Directive[GrayLevel[0.23], AbsoluteThickness[0.9]],
  GridLines -> Automatic,
  GridLinesStyle -> Directive[gridColour, Thin],
  FrameTicksStyle -> Directive[GrayLevel[0.23], 11.5],
  BaseStyle -> {FontFamily -> "Times", 13},
  FrameLabel -> {
   Style[Row[{h, " = ", x, " = ", y}], 15],
   Style[Row[{"order parameter  ", Subscript[m, "A"], " = ",
      Subscript[m, "B"]}], 14]
  },
  PlotRange -> {{fieldMinimum, fieldMaximum}, {-1, 1}},
  PlotRangePadding -> Scaled[0.012],
  ImagePadding -> {{68, 24}, {60, 34}},
  PlotLabel -> Style[
   "Exact finite-size rounding and thermodynamic branch selection",
   13.5, FontFamily -> "Times"
  ],
  AspectRatio -> 0.65,
  ImageSize -> 720
];

figure39 = Legended[
  figure39Raw,
  Placed[
   LineLegend[
    Join[
     (Directive[#, AbsoluteThickness[2.25]] & /@ finiteColours),
     {Directive[thermodynamicColour, Dashed, AbsoluteThickness[2.5]]}
    ],
    Join[
     (Row[{"exact finite size, N = ", #}] & /@ nTotals),
     {"thermodynamic global maximiser"}
    ],
    LegendLayout -> "Column",
    LabelStyle -> {FontFamily -> "Times", 10.8}
   ],
   {0.25, 0.80}
  ]
];

exportPath = FileNameJoin[{figureDirectory,
   "figure3_9_finite_thermodynamic_V2.pdf"}];
Export[exportPath, figure39, "PDF"];

Print["SUCCESS. Code version: ", codeVersion];
Print["PDF exported to this exact path: ", exportPath];
