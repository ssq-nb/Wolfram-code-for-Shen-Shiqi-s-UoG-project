(* ::Package:: *)

Module[{s,f,top,hs,ml,mr,m0,u,v,p1,p2,fig,colors,dir,file},
s[z_?NumericQ] := If[Abs[z] >= 1, 0.,
 -(1+z)/2 Log[(1+z)/2]-(1-z)/2 Log[(1-z)/2]];
hs=-0.07925922930167; ml=-0.4284690161371; mr=0.8659919628855; m0=0.301796459191; top=0.7207946840785;
f[a_?NumericQ,b_?NumericQ] := hs (a+b)/2 + 3/2 ((a^2+a b+b^2)/8 +
 (a^2 b+a b^2)/16) + (s[a]+s[b])/2 - top;
colors={RGBColor[0.14901960784313725,0.2,0.30980392156862746],RGBColor[0.2627450980392157,0.3568627450980392,0.47843137254901963],RGBColor[0.4,0.5176470588235295,0.5607843137254902],RGBColor[0.596078431372549,0.6784313725490196,0.6509803921568628]};
p1=Plot3D[f[u,v],{u,-1,1},{v,-1,1},PlotPoints->70,MaxRecursion->2,
 Mesh->None,PlotRange->All,ColorFunction->Function[{x,y,z},Blend[colors,z]],
 ColorFunctionScaling->True,Lighting->"Neutral",AxesLabel->{Subscript[Style["m",Italic],"A"],Subscript[Style["m",Italic],"B"],"F - Fmax"},
 BaseStyle->{FontFamily->"Times",FontSize->13},PlotLabel->"(a)",
 ImageSize->550,ImagePadding->{{45,40},{35,30}}];
p2=ContourPlot[f[u,v],{u,-1,1},{v,-1,1},PlotPoints->100,MaxRecursion->2,
 Contours->24,ColorFunction->Function[z,Blend[colors,z]],ColorFunctionScaling->True,
 ContourStyle->Directive[GrayLevel[.83],AbsoluteThickness[.45]],
 FrameLabel->{Subscript[Style["m",Italic],"A"],Subscript[Style["m",Italic],"B"]},PlotRange->All,
 Epilog->{Directive[GrayLevel[.85],Dashed],Line[{{-1,-1},{1,1}}],
  RGBColor[0.6078431372549019,0.27058823529411763,0.26666666666666666],PointSize[.019],Point[{{ml,ml},{mr,mr}}],Black,Point[{m0,m0}]},
 PlotLegends->Automatic,BaseStyle->{FontFamily->"Times",FontSize->13},
 PlotLabel->"(b)",ImageSize->550,ImagePadding->{{50,25},{45,30}}];
fig=GraphicsRow[{p1,p2},Spacings->15,ImageSize->1100,Background->White];
dir=If[StringLength[$InputFileName]>0,DirectoryName[ExpandFileName[$InputFileName]],
 Quiet[Check[NotebookDirectory[],Directory[]]]];If[!StringQ[dir],dir=Directory[]];
file=FileNameJoin[{dir,"figure3_11_pressure_landscape.pdf"}];
Export[file,fig,"PDF"];Print["PDF exported: ",file];fig]
